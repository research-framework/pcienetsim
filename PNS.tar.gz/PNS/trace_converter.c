
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define IO_TIME_GAP 1.0
#define SIZE_SSD 34359738368		//32GB in B
#define NUM_BLOCK SIZE_SSD/512		//in 512B-sector

#define NUM_TRACE 1000000


int main(int argc, char *argv[])
{
	char infilename[30];
	char outfilename[30];	
	strcpy(infilename, argv[1]);
	strcpy(outfilename, infilename);	
	strcat(outfilename, "-pns");

	FILE * rfp = fopen(infilename, "rt");
	FILE * wfp = fopen(outfilename, "wt");

	int t1, t2, t3, t4;
	double t5;
	char reqType[10];
	unsigned long long int reqBlkAddr;
	unsigned long long int i;
        unsigned short reqSize;

	unsigned long long int io = 0;
	
	double time = IO_TIME_GAP; 	//10us
	int dev = 0;	
	int op = 0;
	unsigned long long int blk;

	unsigned long long int stat_mod_blk_range = 0;
	
        while(1)
	{
		if(fscanf(rfp, "%d %d %d %d %s %llu %hu", &t1, &t2, &t3, &t4, reqType, &reqBlkAddr, &reqSize) == EOF) break;
		//if(fscanf(rfp, "%d %e %d %d %s %llu %hu", &t1, &t5, &t3, &t4, reqType, &reqBlkAddr, &reqSize) == EOF) break;

		//printf("type[%s] addr[%llu] size[%hu]\n", reqType, reqBlkAddr, reqSize);

		
		fprintf(wfp, "%s %llu %hu\n", reqType, reqBlkAddr, reqSize);
	

	}

	//printf("num cut address:%llu\n", stat_mod_blk_range);
	
	fclose(rfp);
	fclose(wfp);


	return 0;
}
