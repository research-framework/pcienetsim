
#include <queue>
#include <iostream>
#include "PcieSwitch.h"


using namespace std;


PcieSwitch::PcieSwitch(int id, UINT16 dev)
{
	//std::cout << "sw constructor" << std::endl;
	this->swId = id;
	this->numSubDev = dev;
}



PcieSwitch::~PcieSwitch()
{
	//std::cout << "sw destructor" << std::endl;
}



void PcieSwitch::initSw(UINT16 nPort, UINT32 sBuf, UINT16 nLane)
{
	this->numPort = nPort;
        this->sizeBuf = sBuf;
        this->numLane = nLane;

	UINT32 sizeIngBuf = this->sizeBuf / this->numPort;
	UINT32 sizeEgrBuf = this->sizeBuf / this->numPort;
	UINT32 shareUpEgrBuf = sizeEgrBuf / this->numPort;
	
        for(int i=0; i<numPort; i++)
        {
                queue<PciePacket *> * swingq = new queue<PciePacket *>();
                this->SwitchPortIngQ.push_back(swingq);
	
		for(int j=0; j<numPort; j++)
		{
			queue<PciePacket *> * swegrq = new queue<PciePacket *>();
                	this->SwitchPortEgrQ[i].push_back(swegrq);
		}

                this->freeIngBuf[i] = sizeIngBuf;
		this->freeEgrBuf[i] = sizeEgrBuf;
		this->freeUpEgrBuf[i] = shareUpEgrBuf;
		this->busyPortIng[i] = false;
		this->portRelTime[i] = 0;
        }

	this->curUpArb = 0;
}


//need to validate this
int PcieSwitch::detEgrPort(bool last, PciePacket * pkt)
{
	if(((pkt->dstDev) - (this->numSubDev)*(this->swId)) < 0)
		cout << "here wrong id[" << pkt->pktId << "] target[" << pkt->dstDev << "] sw[" << this->swId << "] #sub[" << this->numSubDev << "]" << endl; 
	
	int tarPort;

	if(last)
		tarPort = ((pkt->dstDev) - (this->numSubDev)*(this->swId)) % (this->numPort-1);
	else
		tarPort = ((pkt->dstDev) - (this->numSubDev)*(this->swId)) / (this->numPort-1);

	return (tarPort+1);
}



bool PcieSwitch::isFreeIngBuf(UINT16 nPort, PciePacket * pkt)
{	
	if(this->freeIngBuf[nPort] >= pkt->pktSize)
		return true;
	else
		return false;
}  


  
bool PcieSwitch::isFreeEgrBuf(UINT16 srcPort, UINT16 dstPort, PciePacket * pkt)
{
	UINT32 freeBuf = 0;
	
	if(srcPort == 0)
		freeBuf = this->freeEgrBuf[dstPort];
	else		
		freeBuf = this->freeUpEgrBuf[srcPort];
		
	if(freeBuf >= pkt->pktSize)
		return true;
	else
		return false;

}



void PcieSwitch::bufIngPort(UINT16 nPort, PciePacket * pkt)
{
	(*(this->SwitchPortIngQ[nPort])).push(pkt);
}



void PcieSwitch::resvIngPortRsc(UINT16 nPort, PciePacket * pkt)
{
	this->freeIngBuf[nPort] -= pkt->pktSize;
}




void PcieSwitch::bufEgrPort(UINT16 src, UINT16 dst, PciePacket * pkt)
{
	(*(this->SwitchPortEgrQ[dst][src])).push(pkt);
	this->freeIngBuf[src] += pkt->pktSize;
}



void PcieSwitch::resvEgrPortRsc(UINT16 srcPort, UINT16 dstPort, PciePacket * pkt)
{
	if(srcPort == 0)
		this->freeEgrBuf[dstPort] -= pkt->pktSize;
	else
		this->freeUpEgrBuf[srcPort] -= pkt->pktSize;
}



void PcieSwitch::relEgrPortBuf(UINT16 srcPort, UINT16 dstPort, PciePacket * pkt)
{
	if(dstPort == 0)
		this->freeUpEgrBuf[srcPort] += pkt->pktSize;	
	else
		this->freeEgrBuf[dstPort] += pkt->pktSize;
}



void PcieSwitch::startSwitching(UINT16 nPort)
{
	this->busyPortIng[nPort] = true;
}



void PcieSwitch::endSwitching(UINT16 nPort)
{
	this->busyPortIng[nPort] = false;
}



bool PcieSwitch::statSwitching(UINT16 nPort)
{
	return this->busyPortIng[nPort];
}



void PcieSwitch::setPortRelTime(UINT16 nPort, UINT64 nTime)
{
	this->portRelTime[nPort] = nTime;
}



UINT64 PcieSwitch::getPortRelTime(UINT16 nPort)
{
	return this->portRelTime[nPort];
}



UINT16 PcieSwitch::arbitRR()
{
	this->curUpArb ++;
        
	if(this->curUpArb == this->numPort)
                this->curUpArb = 1;

        return this->curUpArb;
}
