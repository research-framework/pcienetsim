
#include <iostream>
#include <stdio.h>
#include "TypeSystem.h"
#include "PcieLink.h"

using namespace std;


PcieLink::PcieLink()
{
	//cout << "link creator" << endl;
}



PcieLink::~PcieLink()
{
	//cout << "link distructor" << endl;
}



void PcieLink::initLink(UINT16 nVer, UINT16 nLane)
{
	this->numLane = nLane;
	this->upInUse = false;
	this->downInUse = false;

	if(nVer == 1)
	{
		this->dataRate = TRANSFER_RATE_V1;
	}
	else if(nVer == 2)
	{
		this->dataRate = TRANSFER_RATE_V2;
	}
	else if(nVer == 3)
	{
		this->dataRate = TRANSFER_RATE_V3;
	}
	else if(nVer == 4)
	{
		this->dataRate = TRANSFER_RATE_V4;
	}
}



void PcieLink::getUpLink(PciePacket * pkt)
{
	this->upLink = pkt;
	this->upInUse = true;
}



void PcieLink::getDownLink(PciePacket * pkt)
{
	this->downLink = pkt;
	this->downInUse = true;
}


PciePacket* PcieLink::relUpLink()
{
	PciePacket *pkt = this->upLink;
	this->upLink = 0;
	this->upInUse = false;
	return pkt;
}


PciePacket* PcieLink::relDownLink()
{
	PciePacket *pkt = this->downLink;
	this->downLink = 0;
	this->downInUse = false;
	return pkt;
}


bool PcieLink::isUpInUse()
{
	return this->upInUse;
}


bool PcieLink::isDownInUse()
{
	return this->downInUse;
}



UINT64 PcieLink::setUpRelTime(UINT64 gTime, UINT16 sizePkt)
{
	//UINT64 transferTime = sizePkt / this->numLane;
	//if(sizePkt % this->numLane)	transferTime++;
	
	UINT64 transferTime = (((UINT64)sizePkt * 1000000000) / this->dataRate) + 1;

	this->upRelTime = gTime + transferTime;
	return transferTime;
}
 


UINT64 PcieLink::setDownRelTime(UINT64 gTime, UINT16 sizePkt)
{
	//UINT64 transferTime = sizePkt / this->numLane;
	//if(sizePkt % this->numLane)	transferTime++;
	
	UINT64 transferTime = ((UINT64)sizePkt * 1000000000) / this->dataRate + 1;
	
	this->downRelTime = gTime + transferTime;
	return transferTime;
}


UINT64 PcieLink::getUpRelTime()
{
	return this->upRelTime;
}


UINT64 PcieLink::getDownRelTime()
{
	return this->downRelTime;
}

