
#include <iostream>
#include <queue>
#include <vector>

#include "PcieSpec.h"
#include "PciePacket.h"
#include "PcieEndPoint.h"

using namespace std;

PcieEndPoint::PcieEndPoint()
{
	//std::cout << "ep constructor" << std::endl;
}



PcieEndPoint::~PcieEndPoint()
{
	//std::cout << "ep destructor" << std::endl;
}



void PcieEndPoint::initEp(UINT16 nPort, UINT32 sBuf, UINT16 nLane)
{
	this->numPort = nPort;
        this->sizeBuf = sBuf;
        this->numLane = nLane;
 
	this->freeIngBuf = this->sizeBuf;
	this->freeEgrBuf = this->sizeBuf;	

	this->numDiffIo = 0;
}



void PcieEndPoint::bufIng(PciePacket * pkt)
{
	if(numDiffIo)
	{
		for(int i=0; i<numDiffIo; i++)
		{
			if((*(this->EpPortIngQ[i]))[0]->reqId == pkt->reqId)
			{
				(*(this->EpPortIngQ[i])).push_back(pkt);
				return;	
			}
		}		
	}
		
	vector<PciePacket *> * Io = new vector<PciePacket *>();
	(*Io).push_back(pkt);
	(this->EpPortIngQ).push_back(Io);
	this->numDiffIo++;
}
 


void PcieEndPoint::bufEgr(PciePacket * pkt)
{
	(this->EpPortEgrQ).push(pkt);
}




bool PcieEndPoint::isFreeIngBuf(PciePacket * pkt)
{
	if(this->freeIngBuf >= pkt->pktSize)
		return true;
	else
		return false;
}



bool PcieEndPoint::isFreeEgrBuf(PciePacket * pkt)
{
	if(this->freeEgrBuf >= pkt->pktSize)
		return true;
	else
		return false;
}



void PcieEndPoint::resvIngPortRsc(PciePacket * pkt)
{
	this->freeIngBuf -= pkt->pktSize;
}



void PcieEndPoint::resvEgrPortRsc(PciePacket * pkt)
{
	this->freeEgrBuf -= pkt->pktSize;
}



void PcieEndPoint::relEgrPortBuf(PciePacket * pkt)
{
	this->freeEgrBuf += pkt->pktSize;
}



void PcieEndPoint::popFrontIo(PKT_TYPE type, UINT8 parLvl)
{
	if(type == PKT_TYPE_R_REQ)
	{
		this->freeIngBuf += SIZE_PACKET_HEADER;
	}
	else if(type == PKT_TYPE_W_REQ)
	{
		this->freeIngBuf += ((SIZE_PACKET_HEADER+SIZE_PAYLOAD_MAX)*parLvl);
	}

	this->numDiffIo --;

	(*(this->EpPortIngQ[0])).clear();
	(this->EpPortIngQ).erase((this->EpPortIngQ).begin());

}



PciePacket * PcieEndPoint::genRpdPacket(UINT32 id, FLASH_REQ_TYPE type, UINT32 io, UINT32 flash)
{
	PciePacket * pkt = new PciePacket();
	if(!pkt) return 0;

	pkt->pktId = id;
	pkt->pktType = (type == FLASH_REQ_TYPE_R) ? PKT_TYPE_R_DATA : PKT_TYPE_W_CPL;
	pkt->dstDev = flash;
	pkt->reqId = io;
	//pkt->intraPar = na;
	
	if(pkt->pktType == PKT_TYPE_R_DATA)
	{
		pkt->pktSize = SIZE_PACKET_HEADER + SIZE_PAYLOAD_MAX;
	}
	else if(pkt->pktType == PKT_TYPE_W_CPL)
	{
		pkt->pktSize = SIZE_PACKET_HEADER;
	}

	return pkt;
}



