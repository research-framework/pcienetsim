
#include <iostream>
#include <queue>
#include <vector>
#include <string.h>

#include "PcieSpec.h"
#include "SysConfig.h"
#include "PcieNetSimSystem.h"
#include "IoRequest.h"
#include "PciePacket.h"
#include "PcieRootComplex.h"
#include "PcieEndPoint.h"
#include "PcieLink.h"
#include "FlashDev.h"


using namespace std;

FilePointers fps;

SysConfig SysConf;
RcConfig RcConf;
SwConfig SwConf[LIMIT_SW_LAY];
EpConfig EpConf;
LinkConfig LinkConf[LIMIT_SW_LAY];




PcieNetSimSystem::PcieNetSimSystem()
{
	//std::cout << "PcieNetSimSystem constructor" << std::endl;
	
	numReq=0, numPkt=0, cplReq=0, moreCmd=true, gTime=0, totalData=0;

	//stats - rc-related
	for(int i=0; i<RcConf.numPort; i++)
	{
		this->proData[i] = 0;
		this->conData[i] = 0;
		for(int j=0; j<RcConf.numPort; j++)
			this->movData[i][j] = 0;
	}
}



PcieNetSimSystem::~PcieNetSimSystem()
{
	//std::cout << "PcieNetSimSystem destructor" << std::endl;
}



void PcieNetSimSystem::setSysConfig()
{
	
	//SysConf.numSwLayer = 1;
	//SysConf.sizePg = 4;		//KB
	//SysConf.numDev = 8;
	//SysConf.numPar = 4;
	//SysConf.numDigDev = 3;
	//SysConf.numDigPar = 2;
	
	//SysConf.sizeCmdQ = 10000;

		//1  (32768)
		//2  (32768)
		//4  (32768)
		//8  (32768)
		//16 (16384)
		//32 (8192)
		//64 (4096)
		//128 (2048)
		//256 (1024)
		//512 (512)
		//1024(256)
		//2048(128)
		//4096(64)

	
	//cout << "RcConf.numPort " << RcConf.numPort << endl;
	//cout << "RcConf.numLane " << RcConf.numLane << endl;
	//cout << "RcConf.sizePortBuf " << RcConf.sizePortBuf << endl;
	
	//RcConf.numPort = 4;
	//RcConf.numLane = 128;
	//RcConf.sizePortBuf = 102400;	//100KB


	//cout << "LinkConf[0].numLink " << LinkConf[0].numLink << endl;  
	//cout << "LinkConf[0].numLane " << LinkConf[0].numLane << endl;  

	//LinkConf[0].numLink = 4;
	//LinkConf[0].numLane = 32;

	//cout << "SwConf[0].numSwitch " << SwConf[0].numSwitch << endl;
	//cout << "SwConf[0].numPort " << SwConf[0].numPort << endl;
	//cout << "SwConf[0].numLane " << SwConf[0].numLane << endl;
	//cout << "SwConf[0].sizePortBuf " << SwConf[0].sizePortBuf << endl;
	//cout << "SwConf[0].latSw " << SwConf[0].latSw << endl;

	//SwConf[0].numSwitch = 4;
	//SwConf[0].numPort = 3;	
	//SwConf[0].numLane = 96;	
	//SwConf[0].sizePortBuf = 16777216;	//16MB
	//SwConf[0].latSw = 50;

	//cout << "LinkConf[1].numLink " << LinkConf[1].numLink << endl;  
	//cout << "LinkConf[1].numLane " << LinkConf[1].numLane << endl;  

	//LinkConf[1].numLink = 8;
	//LinkConf[1].numLane = 32;

	//SwConf[1].numSwitch = 128;
	//SwConf[1].numPort = 33;	
	//SwConf[1].numLane = 96;	
	//SwConf[1].sizePortBuf = 16777216;	//16MB
	//SwConf[1].latSw = 50;

	//LinkConf[2].numLink = 4096;
	//LinkConf[2].numLane = 32;

	//cout << "EpConf.numEndpoint " << EpConf.numEndpoint << endl;
	//cout << "EpConf.numPort " << EpConf.numPort << endl;
	//cout << "EpConf.numLane " << EpConf.numLane << endl;
	//cout << "EpConf.sizePortBuf " << EpConf.sizePortBuf << endl;

	//EpConf.numEndpoint = 8;	//SysConf.numDev
	//EpConf.numPort = 1;	
	//EpConf.numLane = 1;	
	//EpConf.sizePortBuf = 4194304;		//4MB
}



bool PcieNetSimSystem::buildSystem()
{

	//construt rc
	this->Rc = new PcieRootComplex();	
	if(!(this->Rc)) return false;
	(this->Rc)->initRc(RcConf.numPort, RcConf.numLane);
	

	//construt sw-tree	
	UINT16 numSubDev;	//number of devices under the switch
	for(int i=0; i<SysConf.numSwLayer; i++)
	{	
		if(i==0)
			numSubDev = SysConf.numDev / RcConf.numPort;
		else 
			numSubDev = numSubDev / (SwConf[i-1].numPort-1);
		
 
		//cout << "lay[" << i << "] subDev[" << numSubDev << "]" << endl;	

	
		for(int j=0; j<SwConf[i].numSwitch; j++)	//j is switch # in the same layer
		{
			PcieSwitch * sw = new PcieSwitch(j, numSubDev);
			if(!sw) return false;
			sw->initSw(SwConf[i].numPort, SwConf[i].sizePortBuf, SwConf[i].numLane);
			(this->SwTree[i]).push_back(sw);
		}		
	}

	
	//construct ep
	for(int i=0; i<EpConf.numEndpoint; i++)
	{
		PcieEndPoint * ep = new PcieEndPoint();
		if(!ep) return false;
		ep->initEp(EpConf.numPort, EpConf.sizePortBuf, EpConf.numLane);
		(this->Ep).push_back(ep);
	}


	//construct flash
	for(int i=0; i<SysConf.numDev; i++)
	{
		FlashDev * flash = new FlashDev();
		if(!flash) return false;
		(this->Flash).push_back(flash);
	
		this->flashTime[i] = 0;
	}


	//construct link
	PcieLink * link;
	for(int i=0; i<SysConf.numSwLayer; i++)
	{
		for(int j=0; j<LinkConf[i].numLink; j++)
		{
			link = new PcieLink();
			if(!link) return false;
			link->initLink(LinkConf[i].numVer, LinkConf[i].numLane);
			(this->Link[i]).push_back(link);
		
			this->statLinkTime[i][j] = 0;
		}
	}

	for(int j=0; j<LinkConf[SysConf.numSwLayer].numLink; j++)
	{
		link =  new PcieLink();
		if(!link) return false;
		link->initLink(LinkConf[SysConf.numSwLayer].numVer, LinkConf[SysConf.numSwLayer].numLane);
		(this->Link[SysConf.numSwLayer]).push_back(link);
	}


	//initialization
	this->freeCmdQEnt = SysConf.sizeCmdQ;

	this->moveWrite = 0;

	return true;
}






bool PcieNetSimSystem::addIoRequest(char reqType, UINT64 reqAddr, UINT16 reqSize)
{
	IoRequest *io = new IoRequest();
	if(!io)	return false;

	io->reqId = this->numReq;
	io->reqType = (reqType == 'r') ? REQ_TYPE_R : REQ_TYPE_W;
	io->reqAddr = reqAddr;
	io->reqSize = reqSize;

	//cout << (io)->reqId << " "  << (io)->reqType << " "  << (io)->reqAddr << " " << (io)->reqSize << endl;

	(this->reqList).push_back(io);
	(this->numReq)++; 
	(this->freeCmdQEnt)--;

	divIoRequest(io);

	return true;
}



bool PcieNetSimSystem::modIoRequest(UINT32 reqId)
{
	std::vector<IoRequest *>::iterator itr;	
		
	for(itr=reqList.begin(); itr!=reqList.end(); itr++)
	{
		if((*itr)->reqId == reqId)
		{
			//std::cout << (*itr)->reqId << std::endl;
			return true;
		}
	}

	return false;
}



bool PcieNetSimSystem::cplIoRequest(IoRequest * io, PciePacket * lastPkt)
{		
	//cout << "IO[" << io->reqId << "] completed" << endl;		
	UINT64 lat = 0;

	this->totalData += (UINT64)(io->reqSize * 512);


	//logging
	fprintf(this->brkOut, "IO[%d] ", io->reqId);
	for(int i=0; i<(io->reqPktList).size(); i++)
	{
		PciePacket * reqPkt = (io->reqPktList)[i];
		//fprintf(this->brkOut, "reqPkt[%d]-dev(%d) lastPkt[%d]-dev(%d)", reqPkt->pktId, reqPkt->dstDev, lastPkt->pktId, lastPkt->dstDev);


		if(lastPkt->dstDev == reqPkt->dstDev)
		{
			//fprintf(this->brkOut, "pkt[%d] ", reqPkt->pktId);
			for(int j=0; j<reqPkt->curDevId; j++)
			{
				fprintf(this->brkOut, "%llu ", reqPkt->latBrk[j]);
				lat += reqPkt->latBrk[j];
			}
		

			//fprintf(this->brkOut, "pkt[%d] ", lastPkt->pktId);
			for(int j=0; j<lastPkt->curDevId; j++)
			{
				fprintf(this->brkOut, "%llu ", lastPkt->latBrk[j]);	
				lat += lastPkt->latBrk[j];
			}	
			break;
		}
	}
	fprintf(this->brkOut, "%llu\n", lat);


	//increase a queue entry
	(this->freeCmdQEnt)++;	
	vector<IoRequest *>::iterator itr;
	for(itr=(this->reqList).begin(); itr!=(this->reqList).end(); itr++)
	{
		if((*itr)->reqId == io->reqId)	break;
	}
	(this->reqList).erase(itr);


	//free memory
	int numReqPkt = (io->reqPktList).size();
	int numRpdPkt = (io->rpdPktList).size();
	for(int i=0; i<numReqPkt; i++)	delete((io->reqPktList)[i]);
	for(int i=0; i<numRpdPkt; i++)	delete((io->rpdPktList)[i]);
	delete(io);	

	
	this->cplReq ++;	

	//if(this->freeCmdQEnt == SysConf.sizeCmdQ)
	//	fclose(this->brkOut);

	return true;
}



bool PcieNetSimSystem::divIoRequest(IoRequest *io)
{
	UINT16 secReq = io->reqSize;	
	UINT16 secPg = SysConf.sizePg * 2;
	
	UINT64 lbn = (UINT64)(io->reqAddr / secPg);
	UINT16 lbnAlign = (UINT16)(io->reqAddr % secPg);
	if(lbnAlign != 0)	lbnAlign = secPg - lbnAlign;

	UINT16 curDstDev = calDstDev(lbn);

	//extracting flash transactions
	if(lbnAlign >= secReq)
	{
		io->lbn[io->numTarDev].push_back(lbn);
	}
	else
	{	
		if(lbnAlign)
		{	
			io->lbn[io->numTarDev].push_back(lbn);
			secReq -= lbnAlign;
			lbn += 1;
		}

	
		UINT16 numTrans = secReq / secPg;
		UINT16 remSec = secReq % secPg;	
		if(numTrans == 0)
		{
			numTrans = 1;
			remSec = 0;
		}	
	
		for(int i=0; i<numTrans; i++)
		{
			if(curDstDev != calDstDev(lbn))			
			{
				curDstDev = calDstDev(lbn);
				io->numTarDev++;
			}
		
			io->lbn[io->numTarDev].push_back(lbn);
			lbn += 1;		
		}

		if(remSec)
		{	
			if(curDstDev != calDstDev(lbn))
			{
				io->numTarDev++;
			}
			io->lbn[io->numTarDev].push_back(lbn);
		}
	}
		
	io->numTarDev++;

	//generating pcie packets from flash transactions
	
	vector<UINT64>::iterator itr;
	PciePacket * pkt;
	
	for(int i=0; i<io->numTarDev; i++)
	{
		if(io->reqType == REQ_TYPE_R)	//rd req
		{
			itr=(io->lbn[i]).begin();
			pkt = genPackets(io->reqId, io->reqType, calDstDev(*itr), (io->lbn[i]).size()); 
			if(!pkt) return false;
			(io->reqPktList).push_back(pkt);
			//cout << " " << (io->reqPktList).size() << endl;
		}
		else				//wr req + data
		{
			for(itr=(io->lbn[i]).begin(); itr!=(io->lbn[i]).end(); itr++)
			{
				pkt = genPackets(io->reqId, io->reqType, calDstDev(*itr), (io->lbn[i]).size()); 
				if(!pkt) return false;
				(io->reqPktList).push_back(pkt);
				//cout << " " << (io->reqPktList).size() << endl;

			}	
		}
	}


	//when to complete I/O

	if(io->reqType == REQ_TYPE_W)	//write cpl from each dev
	{
		io->numWaitRpdPkt = io->numTarDev;
	}
	else	//read data for each page
	{
		for(int i=0; i<io->numTarDev; i++)
		{
			io->numWaitRpdPkt += (io->lbn[i]).size();
		}
	}

	//cout << io->numWaitRpdPkt << endl;

#if DEBUG	
	vector<UINT64>::iterator itr;	
	for(int i=0; i<io->numTarDev; i++)
	{
		cout << " ("; 
		for(itr=(io->lbn[i]).begin(); itr!=(io->lbn[i]).end(); itr++)
		{	
			cout << (*itr) << " ";
		}
		cout << ") ";
	}
	cout << endl;
#endif

	return true;
}



PciePacket * PcieNetSimSystem::genPackets(UINT32 reqId, REQ_TYPE op, UINT16 dev, UINT32 par)
{	
	
	PciePacket *pkt = new PciePacket();
	if(!pkt) return 0;
		
	pkt->pktId = this->numPkt; 
	pkt->pktType = (op == REQ_TYPE_R) ? PKT_TYPE_R_REQ : PKT_TYPE_W_REQ;
	pkt->dstDev = dev;
	pkt->reqId = reqId;
	pkt->intraPar = par;
	pkt->curDevId = 0;
	pkt->curTime = this->getGblTime();

	if(op == REQ_TYPE_R)
	{
		pkt->pktSize = SIZE_PACKET_HEADER; 
	}
	else
	{
		pkt->pktSize = SIZE_PACKET_HEADER + SIZE_PAYLOAD_MAX;
	}


	this->numPkt++;

	//insert RP queue!!!
	(*((this->Rc)->RootPortQ[(this->Rc)->detEgrPort(pkt)])).push(pkt);

	//cout << reqId << " " << pkt->pktId << " " << op << " " << dev << " " << (this->Rc)->detEgrPort(pkt) << " " << par << " ";  
	
	return pkt;
}



UINT16 PcieNetSimSystem::calDstDev(UINT64 lbn)
{
	UINT16 dstDev = lbn >> SysConf.numDigPar;
	dstDev &= (SysConf.numDev-1);
	return dstDev;
}



void PcieNetSimSystem::simulateSys()
{
	this->brkOut = fopen(BRKDOWN_FILE_NAME, "wt");
	//this->statOut = fopen(STAT_FILE_NAME, "wt");
	
	while(1)
	{
		if(this->freeCmdQEnt && this->moreCmd)
		{
			//cout << "free[" << this->freeCmdQEnt << "] cmd[" <<  this->moreCmd << "]" << endl;
			getIoRequest(fps.inIoTrace);
		}

		this->updateSys();
		
		this->advClock();
		//cout << "-----------------------------------" << getGblTime() << endl;

		if((this->freeCmdQEnt == SysConf.sizeCmdQ) && (this->moreCmd == false)) break;
		
		if(getGblTime() == 100000000)
		{
			break;
			//this->moreCmd = false;	
		}
	}

	fclose(this->brkOut);

	cout << "simulation time (ns) " << getGblTime() << endl;
	cout << "completed requests " << this->cplReq << endl;
	cout << "completed data size (B) " <<  this->totalData << endl;

	//fprintf(this->statOut, "%llu\n", getGblTime());
	//fprintf(this->statOut, "%u\n", this->cplReq);
	//fprintf(this->statOut, "%llu\n", this->totalData);
	//this->statPrint(getGblTime());
	//fclose(this->statOut);
	
}



void PcieNetSimSystem::getIoRequest(FILE *ioInStream)
{
        char reqType[10];
        UINT64 reqBlkAddr;
        UINT16 reqSize;
	int freeEnt = this->freeCmdQEnt;		

	for(int i=0; i<freeEnt; i++)
	{		

		if(fscanf(ioInStream, "%s %llu %hu", reqType, &reqBlkAddr, &reqSize) == EOF)		 
		{	
			//cout << "No more IO requests" << endl;
			fclose(ioInStream);
			this->moreCmd = false;
			return;
		}
		

		if(!this->addIoRequest(strcmp(reqType, "Read") ? 'w' : 'r', reqBlkAddr, reqSize))
		{
			//cout << "Adding IO request failed" << endl;
		}
	}
}



void PcieNetSimSystem::updateSys()
{
	this->updateRc();
	this->updateSwTree();
	this->updateEp();
	this->updateLink();
}



void PcieNetSimSystem::updateRc()
{
	
	for(int i=0; i<RcConf.numPort; i++)
	{
		queue<PciePacket *> * currRcQ = (this->Rc)->RootPortQ[i];
	
		//cout << "rp[" << i << "] has " << (*currRcQ).size() << endl; 	
		if((*currRcQ).size())
		{
			PciePacket * pkt = (*currRcQ).front();
			//cout << "rc front pkt " << pkt->pktId << endl;
			PcieLink * nextLink = this->Link[0][i];
			PcieSwitch * nextSw = this->SwTree[0][i];
	
			if((!(nextLink->isDownInUse())) && (nextSw->isFreeIngBuf(0, pkt)))
			{		
				(*currRcQ).pop();
				//if((*currRcQ).size())
				//	cout << "pop & next " << ((*currRcQ).front())->pktId << " remain[" << (*currRcQ).size() << "] ";
				//else
				//	cout << "pop &      remain[ " <<  (*currRcQ).size()  << "] ";
				nextLink->getDownLink(pkt);	
				nextLink->setDownRelTime(this->getGblTime(), pkt->pktSize);	
				//cout << nextLink->getDownRelTime() << endl;
				nextSw->resvIngPortRsc(0, pkt);

				this->updatePktTime(pkt);
			}
		}
	}

	
	//for(int i; i<LinkConf[0].numLink; i++)
	//	cout << (((Link[0])[i])->downLink)->pktId << endl;	
}
                


void PcieNetSimSystem::updateSwTree()
{
	for(int lay=0; lay<SysConf.numSwLayer; lay++)
	{
		for(int sw=0; sw<SwConf[lay].numSwitch; sw++)
		{
			PcieSwitch * currSw = this->SwTree[lay][sw];
	 
			for(int port=0; port<SwConf[lay].numPort; port++)
			{
				queue<PciePacket *> * currIngBuf = currSw->SwitchPortIngQ[port];

				//Ingress Port Activity

				if((*currIngBuf).size())	//pkts exist
				{
					
					//cout << "sw[" << lay << "][" << sw << "][" << port << "] IngQ[" << (*currIngBuf).size() << "]" << endl;
											
					PciePacket * pkt = (*currIngBuf).front();
					UINT16 dstPort = 0; 
					if(port == 0)
					{
						dstPort = (lay == (SysConf.numSwLayer-1)) ? currSw->detEgrPort(true, pkt) : currSw->detEgrPort(false, pkt);
					}
					
					//cout << "sw[" << lay << "][" << sw << "][" << port << "] " << pkt->pktId << endl; 

					if(!currSw->statSwitching(port))	//rsc avail for switching
					{			
						if(currSw->isFreeEgrBuf(port, dstPort, pkt))	//free target egr buf
						{
							currSw->resvEgrPortRsc(port, dstPort, pkt);
							//if(port == 0)	cout << currSw->freeEgrBuf[dstPort] << " "; 
							//else		cout << currSw->freeUpEgrBuf[port] << " ";	
 								
							currSw->startSwitching(port);
							currSw->setPortRelTime(port, (this->getGblTime()+SwConf[lay].latSw));

							//cout << "Swtching in sw[" << lay << "][" << sw << "][" << port << "] " <<  pkt->pktId << " to [" << dstPort << "]" << endl;
						}
						
					}
					else
					{
						if(currSw->getPortRelTime(port) <= this->getGblTime())
						{
							(*currIngBuf).pop();
							//cout << "dstDev[" << pkt->dstDev << "] from " <<  port << " to " << dstPort << endl;
							currSw->bufEgrPort(port, dstPort, pkt);
							currSw->endSwitching(port);

							//cout << "Buffered in sw[" << lay << "][" << sw << "][" << port << "] " <<  pkt->pktId << " to [" << dstPort << "]" << endl;	
						}
					}
				}
				
					
				//Egress Port Activity

				if(port == 0)		//up
				{
					UINT16 curUp;
					int tar;
	
					for(tar=1; tar<currSw->numPort; tar++)	//arbitration
					{
						curUp = currSw->arbitRR();
						if((*(currSw->SwitchPortEgrQ[0][curUp])).size())	break;
					}

					if(tar == currSw->numPort)	//no packet
					{
						//cout << "sw[" << lay << "][" << sw << "] no packet to process" << endl;
					}	
					else
					{
						PciePacket * pkt = (*(currSw->SwitchPortEgrQ[0][curUp])).front();
						PcieLink * nextLink = this->Link[lay][sw];

						if(lay == 0)	//to rc
						{
							if(!(nextLink->isUpInUse()))
							{
								(*(currSw->SwitchPortEgrQ[0][curUp])).pop();
								//if((*(currSw->SwitchPortEgrQ[0][curUp])).size())
								//	cout << "pop & next " << (*(currSw->SwitchPortEgrQ[0][curUp])).front()->pktId << " remain[" << (*(currSw->SwitchPortEgrQ[0][curUp])).size() << "] ";
								//else
								//	cout << "pop &      remain[ " <<  (*(currSw->SwitchPortEgrQ[0][curUp])).size()  << "] ";
								
								currSw->relEgrPortBuf(curUp, 0, pkt);	
								nextLink->getUpLink(pkt);
								nextLink->setUpRelTime(this->getGblTime(), pkt->pktSize);

								this->statLinkTime[lay][sw] += nextLink->setUpRelTime(this->getGblTime(), pkt->pktSize);

								//cout << nextLink->getUpRelTime() << endl;

								this->updatePktTime(pkt);
							}
							else
							{

							}
						}
						else		//to next previous sw
						{
							PcieSwitch * nextSw = this->SwTree[lay-1][sw/(SwConf[lay-1].numPort-1)];	
							int nextPort = (sw % (SwConf[lay-1].numPort-1)) + 1;
							if(!(nextLink->isUpInUse()) && (nextSw->isFreeIngBuf(nextPort, pkt)))
							{
								(*(currSw->SwitchPortEgrQ[0][curUp])).pop();
								//if((*(currSw->SwitchPortEgrQ[0][curUp])).size())
								//	cout << "pop & next " << (*(currSw->SwitchPortEgrQ[0][curUp])).front()->pktId << " remain[" << (*(currSw->SwitchPortEgrQ[0][curUp])).size() << "] ";
								//else
								//	cout << "pop &      remain[ " <<  (*(currSw->SwitchPortEgrQ[0][curUp])).size()  << "] ";

								currSw->relEgrPortBuf(curUp, 0, pkt);	
								nextLink->getUpLink(pkt);
								nextLink->setUpRelTime(this->getGblTime(), pkt->pktSize);

								this->statLinkTime[lay][sw] += nextLink->setUpRelTime(this->getGblTime(), pkt->pktSize);			

								//cout << nextLink->getUpRelTime() << endl;
								nextSw->resvIngPortRsc(nextPort, pkt);

								this->updatePktTime(pkt);
							}
						}
						
					}
				}
				else		//dps
				{
					queue<PciePacket *> * currEgrBuf = currSw->SwitchPortEgrQ[port][0];
					
					if((*currEgrBuf).size())	//pkts exist
					{
						//cout << "sw[" << lay << "][" << sw << "][" << port << "] EgrQ[" << (*currEgrBuf).size() << "] ";

						PciePacket * pkt = (*currEgrBuf).front();
						//cout << " front pkt " << pkt->pktId << endl;
					
						int nextDevNum = (SwConf[lay].numPort-1) * sw + (port-1);
						PcieLink * nextLink = this->Link[lay+1][nextDevNum];

						if(lay == SysConf.numSwLayer-1)		//to ep
						{
							PcieEndPoint * nextEp = this->Ep[nextDevNum];

							if((!(nextLink->isDownInUse())) && (nextEp->isFreeIngBuf(pkt)))
							{
								(*currEgrBuf).pop();
								//if((*currEgrBuf).size())
								//	cout << "pop & next " << ((*currEgrBuf).front())->pktId << " remain[" << (*currEgrBuf).size() << "] ";
								//else
								//	cout << "pop &      remain[ " <<  (*currEgrBuf).size()  << "] ";
									
								currSw->relEgrPortBuf(0, port, pkt);	
										
								nextLink->getDownLink(pkt);	
								nextLink->setDownRelTime(this->getGblTime(), pkt->pktSize);	
								//cout << nextLink->getDownRelTime() << endl;
								nextEp->resvIngPortRsc(pkt);
							
								this->updatePktTime(pkt);
							}			
						}
						else	//to next layer sw		
						{
							//int nextSwNum = (SwConf[lay].numPort-1) * sw + (port-1);
							//PcieLink * nextLink = this->Link[lay+1][nextSwNum];
							
							PcieSwitch * nextSw = this->SwTree[lay+1][nextDevNum];

							if((!(nextLink->isDownInUse())) && (nextSw->isFreeIngBuf(0, pkt)))
							{
								(*currEgrBuf).pop();
								//if((*currEgrBuf).size())
								//	cout << "pop & next " << ((*currEgrBuf).front())->pktId << " remain[" << (*currEgrBuf).size() << "] ";
								//else
								//	cout << "pop &      remain[ " <<  (*currEgrBuf).size()  << "] ";
							
								currSw->relEgrPortBuf(0, port, pkt);	
	
								nextLink->getDownLink(pkt);	
								nextLink->setDownRelTime(this->getGblTime(), pkt->pktSize);	
								//cout << nextLink->getDownRelTime() << endl;
								nextSw->resvIngPortRsc(0, pkt);

								this->updatePktTime(pkt);
							}
						}
					}
				}
	
			}
		}
	}
}



void PcieNetSimSystem::updateEp()
{
	for(int i=0; i<EpConf.numEndpoint; i++)	 //for each ep
	{
		PcieEndPoint * ep = this->Ep[i];
		FlashDev * flash = this->Flash[i];
	
		//ingress-Q activity
	
		if(!flash->isRun())		//when flash dev is free
		{	
			if((ep->EpPortIngQ).size())		//if buf has packets to process
			{
				PciePacket * frontPkt = (*(ep->EpPortIngQ[0]))[0];	
				
				if(frontPkt->pktType == PKT_TYPE_R_REQ)
				{
					this->flashTime[i] += flash->reqRun(FLASH_REQ_TYPE_R, frontPkt->reqId, frontPkt->intraPar, getGblTime());
						
					//cout << "EP->Flash(read) pkt[" << frontPkt->pktId << "]"  << endl;

					for(int j=0; j<(*(ep->EpPortIngQ[0])).size(); j++)
					{
						this->updatePktTime((*(ep->EpPortIngQ[0]))[j]);
					}

					ep->popFrontIo(frontPkt->pktType, frontPkt->intraPar);
				}
				else if(frontPkt->pktType == PKT_TYPE_W_REQ)
				{
					if(frontPkt->intraPar == (*(ep->EpPortIngQ[0])).size())
					{
						this->flashTime[i] += flash->reqRun(FLASH_REQ_TYPE_W, frontPkt->reqId,  frontPkt->intraPar, getGblTime());
	
						//cout << "EP->Flash(write) ";
						//for(int j=0; j<(*(ep->EpPortIngQ[0])).size(); j++)
						//	cout << "pkt[" << (*(ep->EpPortIngQ[0]))[j]->pktId << "] ";	
						//cout << endl;

						for(int j=0; j<(*(ep->EpPortIngQ[0])).size(); j++)
						{
							this->updatePktTime((*(ep->EpPortIngQ[0]))[j]);
						}

						ep->popFrontIo(frontPkt->pktType, frontPkt->intraPar);
					}
				}
			}
		}
		else
		{
			if(flash->getRelTime() <= getGblTime())		//flash completed trans
			{
				//packets to host generated
				//cout << "flash[" << i << "] " << flash->getIoType() << " completed - parLvl[" << (int)(flash->getParLvl()) << "] ";

				int parLvl = (flash->getIoType() == FLASH_REQ_TYPE_W) ? 1 : flash->getParLvl();
				
				for(int j=0; j<parLvl; j++)
				{
					PciePacket * pkt = ep->genRpdPacket(this->numPkt, flash->getIoType(), flash->getIoId(), i);
					this->numPkt++;
					this->addPktIo(pkt);					
					//cout << "pkt[" <<  pkt->pktId << "] ";	
	
					ep->bufEgr(pkt);
				 
					this->setupPktTime(pkt, flash->runTime);
				}
				//cout << endl;
				UINT64 dataGen;
				dataGen = flash->cplRun();
				this->proData[i/(SysConf.numDev/RcConf.numPort)] += dataGen;

			}
			else
			{
	
			}
		}

		
		//egress-Q activity
	
		if((ep->EpPortEgrQ).size())		//if buf egr has packets to process
		{
			PcieLink * nextLink = this->Link[SysConf.numSwLayer][i];
			PcieSwitch * nextSw = this->SwTree[SysConf.numSwLayer-1][i/(SwConf[SysConf.numSwLayer-1].numPort-1)];
			int nextPort = (i % (SwConf[SysConf.numSwLayer-1].numPort-1)) + 1;
 			PciePacket * pkt = (ep->EpPortEgrQ).front();

			if((!(nextLink->isUpInUse())) && (nextSw->isFreeIngBuf(nextPort, pkt)))
			{
				(ep->EpPortEgrQ).pop();
								
				//if((ep->EpPortEgrQ).size())
				//	cout << "pop & next " << ((ep->EpPortEgrQ).front())->pktId << " remain[" << (ep->EpPortEgrQ).size() << "] ";
				//else
				//	cout << "pop &      remain[ " <<  (ep->EpPortEgrQ).size()  << "] ";
	
				ep->relEgrPortBuf(pkt);				

				nextLink->getUpLink(pkt);
				nextLink->setUpRelTime(this->getGblTime(), pkt->pktSize);
				//cout << nextLink->getUpRelTime() << endl;
				nextSw->resvIngPortRsc(nextPort, pkt);
		
				this->updatePktTime(pkt);
			}
		}
	
	}
}



void PcieNetSimSystem::updateLink()
{
	for(int i=0; i<=SysConf.numSwLayer; i++)
	{
		for(int j=0; j<LinkConf[i].numLink; j++)
		{
			PcieLink * currLink = this->Link[i][j];		

			if(currLink->isDownInUse())
			{
			
				if(currLink->getDownRelTime() <= getGblTime())
				{
					//cout << "downlink[" << i << "][" << j << "] " << (currLink->downLink)->pktId << " " << currLink->getDownRelTime() << " " << getGblTime() <<  endl;	
					PciePacket * pkt = currLink->relDownLink();

					if(i == SysConf.numSwLayer)	//endpoint
					{
						(this->Ep[j])->bufIng(pkt);
						//cout << "EP[" << j << "] pkt[" << pkt->pktId << "]" << endl; 
					}
					else				//next layer switch
					{	
						//cout << "buffered in sw" << endl;
						(this->SwTree[i])[j]->bufIngPort(0, pkt);
					}
					
					this->updatePktTime(pkt);
				}
			}

			if(currLink->isUpInUse())
			{
				if(currLink->getUpRelTime() <= getGblTime())
				{
					//cout << "uplink[" << i << "][" << j << "] " << (currLink->upLink)->pktId <<  " " << currLink->getUpRelTime() << " " << getGblTime() << endl;	

					PciePacket * pkt = currLink->relUpLink();
					
					if(i == 0)	//root complex
					{
						//cout << "pkt[" << pkt->pktId << "] IO[" << pkt->reqId << "] arrived at RC" << endl;
						this->updatePktTime(pkt);
						
						this->conData[j] += SIZE_PAYLOAD_MAX; 

						this->cplPktIo(pkt);
					}
					else		//upper switch
					{
						//cout << "buffered in sw" << endl;
						int sw = j / (SwConf[i-1].numPort-1);
						int port = (j % (SwConf[i-1].numPort-1)) + 1;
						(this->SwTree[i-1])[sw]->bufIngPort(port, pkt);
						this->updatePktTime(pkt);
					}

				}
			}

		}
	} 

}



void PcieNetSimSystem::addPktIo(PciePacket * pkt)
{
	for(int i=0; i<reqList.size(); i++)
	{
		if((this->reqList[i])->reqId == pkt->reqId)
		{		
			((this->reqList[i])->rpdPktList).push_back(pkt);
			break;
		}
	}
}



void PcieNetSimSystem::cplPktIo(PciePacket * pkt)
{
	for(int i=0; i<reqList.size(); i++)
	{
		if((this->reqList[i])->reqId == pkt->reqId)
		{ 
			(this->reqList[i])->numWaitRpdPkt -= 1;
			if((this->reqList[i])->numWaitRpdPkt == 0)
			{
				this->cplIoRequest(this->reqList[i], pkt);
			}
			break; 
		}
	}
}



void PcieNetSimSystem::setupPktTime(PciePacket * pkt, UINT64 flashLat)
{
	pkt->latBrk[0] = flashLat;
	pkt->curTime = this->getGblTime();	
	pkt->curDevId = 1;
}



void PcieNetSimSystem::updatePktTime(PciePacket * pkt)
{
	pkt->latBrk[pkt->curDevId] = (this->getGblTime()) - (pkt->curTime);
	pkt->curTime = this->getGblTime();
	pkt->curDevId ++;
}



UINT64 PcieNetSimSystem::getGblTime()
{
	return this->gTime;
}



void PcieNetSimSystem::setAdvTime(UINT64 adv)
{
	//cout << "adv " << adv << endl;

	if(this->advTime > adv)
		this->advTime = adv;
}



void PcieNetSimSystem::advClock()
{
	//this->gTime += this->advTime;
	//this->advTime = 1000000;	//1ms
	this->gTime++;
}



void PcieNetSimSystem::statPrint(UINT64 runTime)
{
        int i, j;
        int util;
	int utRange[10] = {0,};

        for(i=0; i<SysConf.numSwLayer; i++)
        {
                for(j=0; j<LinkConf[i].numLink; j++)
                {
                        if(j%32 == 0)	fprintf(this->statOut, "\n");

			util = (int)(this->statLinkTime[i][j] * 100 / runTime);
                        fprintf(this->statOut, "%d ", util);
                }
                fprintf(this->statOut, "\n");
        }

	for(i=0; i<RcConf.numPort; i++)
	{
		fprintf(this->statOut, "%llu %llu\n", proData[i], conData[i]);
	}

	for(i=0; i<LinkConf[0].numLink; i++)
	{
		for(j=0; j<LinkConf[0].numLink; j++)
			fprintf(this->statOut, "%llu ", movData[i][j]);
		
		fprintf(this->statOut, "\n");
	}
	fprintf(this->statOut, "\n");

	
	for(i=0; i<EpConf.numEndpoint; i++)	
	{
		if(j%1024 == 0)	fprintf(this->statOut, "\n");
	
		util = (int)(this->flashTime[i] * 100 / runTime);
		fprintf(this->statOut, "%d ", util);
	
		utRange[util/10]++;	
	}	
	fprintf(this->statOut, "\n");

	for(i=0; i<10; i++)
	{
		fprintf(this->statOut, "%d ", utRange[i]);
	}
	fprintf(this->statOut, "\n\n\n");

	
	fprintf(this->statOut, "%d\n", moveWrite);

}

