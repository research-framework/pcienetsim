
#ifndef _PcieRootComplex_h__
#define _PcieRootComplex_h__


#include <queue>
#include <vector>
#include "TypeSystem.h"
#include "PciePacket.h"


#define LIMIT_RC_PORT 1024


class PcieRootComplex {

	public:
		UINT16 numPort;
		UINT16 numLane;

		std::vector< std::queue<PciePacket *> *> RootPortQ;			
				
		PcieRootComplex();
		~PcieRootComplex();

		void initRc(UINT16 nPort, UINT16 nLane);
		int detEgrPort(PciePacket * pkt);	

};


#endif


