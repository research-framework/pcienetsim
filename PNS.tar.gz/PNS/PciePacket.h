
#ifndef _PciePacket_h__
#define _PciePacket_h__

#include "TypeSystem.h"



typedef enum {
        PKT_TYPE_R_REQ,
        PKT_TYPE_R_DATA,	//including cpl
	PKT_TYPE_W_REQ,		//including data
	PKT_TYPE_W_CPL,
} PKT_TYPE;



class PciePacket {

	public:	
	
		UINT32 pktId;		
		PKT_TYPE pktType;
		UINT16 pktSize;		//B

		UINT16 dstDev;
		//UINT16 relDstDev;
		UINT32 reqId;
		UINT8 intraPar;

		UINT64 curTime;
		int curDevId;
		UINT64 latBrk[20];
};




#endif

