
#include <iostream>
#include <fstream>	
#include <string.h>
#include "ParamMgr.h"
#include "PcieNetSimSystem.h"
#include "SysConfig.h"


using namespace std;

extern FilePointers fps;
extern SysConfig SysConf;
extern RcConfig RcConf;
extern SwConfig SwConf[LIMIT_SW_LAY];
extern EpConfig EpConf;
extern LinkConfig LinkConf[LIMIT_SW_LAY];


ParamMgr::ParamMgr()
{
	//cout << "parameter manager created" << endl;
}



ParamMgr::~ParamMgr()
{
	//cout << "parameter manager deleted" << endl;
}



void ParamMgr::mapValue()
{
	char paramItem[20];
	int paramValue, layer;	
	PARAM_TYPE paramType = PARAM_TYPE_NONE;

	while(1)
	{
		if(fscanf(fps.inConfig, "%s %d", paramItem, &paramValue) == EOF) break;

		//cout << paramItem << " -> " << paramValue << endl;
	
		if(!strcmp(paramItem, "[System]"))
		{
			paramType = PARAM_TYPE_SYS;
			//cout << "param system" << endl;
			continue;
		}	
		else if(!strcmp(paramItem, "[RootComplex]"))
		{
			paramType = PARAM_TYPE_RC;
			//cout << "param rc" << endl;
			continue;
		}
		else if(!strcmp(paramItem, "[Link]"))
		{
			paramType = PARAM_TYPE_LINK;
			layer = paramValue;
			//cout << "param link" << endl;
			continue;

		}
		else if(!strcmp(paramItem, "[Switch]"))
		{
			paramType = PARAM_TYPE_SW;
			layer = paramValue;
			//cout << "param switch" << endl;
			continue;
		}
		else if(!strcmp(paramItem, "[EndPoint]"))
		{
			paramType = PARAM_TYPE_EP;
			//cout << "param endpoint" << endl;
			continue;
		}

	

		if(paramType == PARAM_TYPE_SYS)	this->mapSysValue(paramItem, paramValue);
		else if(paramType == PARAM_TYPE_RC) this->mapRcValue(paramItem, paramValue);
		else if(paramType == PARAM_TYPE_SW) this->mapSwValue(paramItem, layer, paramValue);
		else if(paramType == PARAM_TYPE_EP) this->mapEpValue(paramItem, paramValue);
		else if(paramType == PARAM_TYPE_LINK) this->mapLinkValue(paramItem, layer, paramValue);
	}
}



void ParamMgr::mapSysValue(char * item, int value)
{
	if(!strcmp(item, "numQueueEntry"))		SysConf.sizeCmdQ = (UINT16)value;
	else if(!strcmp(item, "numDevice"))		SysConf.numDev = (UINT16)value;
	else if(!strcmp(item, "numSwitchLayer"))	SysConf.numSwLayer = (UINT16)value;
	else if(!strcmp(item, "numDigitDevice"))	SysConf.numDigDev = (UINT8)value;
	else if(!strcmp(item, "numPar"))		SysConf.numPar = (UINT8)value;
	else if(!strcmp(item, "numDigitPar"))		SysConf.numDigPar = (UINT8)value;
	else if(!strcmp(item, "sizePage"))		SysConf.sizePg = (UINT16)value;
}



void ParamMgr::mapRcValue(char * item, int value)
{
	if(!strcmp(item, "numDownPort"))		RcConf.numPort = (UINT16)value;
	else if(!strcmp(item, "numTotalLane"))		RcConf.numLane = (UINT16)value;
}



void ParamMgr::mapSwValue(char * item, int layer, int value)
{
	if(!strcmp(item, "numSwitch"))			SwConf[layer-1].numSwitch = (UINT16)value;
	else if(!strcmp(item, "numPort"))		SwConf[layer-1].numPort = (UINT16)value;
	else if(!strcmp(item, "numTotalLane"))		SwConf[layer-1].numLane = (UINT16)value;
	else if(!strcmp(item, "sizePortBuffer"))	SwConf[layer-1].sizePortBuf = (UINT32)value;
	else if(!strcmp(item, "timeSwitching"))		SwConf[layer-1].latSw = (UINT16)value;
}



void ParamMgr::mapEpValue(char * item, int value)
{
	if(!strcmp(item, "numEndPoint"))		EpConf.numEndpoint = (UINT16)value;
	else if(!strcmp(item, "numPort"))		EpConf.numPort = (UINT16)value;
	else if(!strcmp(item, "numLane"))		EpConf.numLane = (UINT16)value;
	else if(!strcmp(item, "sizePortBuffer"))	EpConf.sizePortBuf = (UINT32)value;
}



void ParamMgr::mapLinkValue(char * item, int layer, int value)
{
	if(!strcmp(item, "numVer"))		LinkConf[layer-1].numVer = (UINT16)value;
	else if(!strcmp(item, "numLink"))	LinkConf[layer-1].numLink = (UINT16)value;
	else if(!strcmp(item, "numLane"))	LinkConf[layer-1].numLane = (UINT16)value;
}
