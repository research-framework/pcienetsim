
#ifndef _PcieEndPoint_h__
#define _PcieEndPoint_h__


#include <vector>
#include <queue>
#include "TypeSystem.h"
#include "PciePacket.h"
#include "FlashDev.h"

using namespace std;


class PcieEndPoint {

	public:
		UINT16 numPort;
		UINT32 sizeBuf;
		vector<vector<PciePacket *> *> EpPortIngQ;
		int numDiffIo;	
		
		queue<PciePacket *> EpPortEgrQ;
		UINT32 freeIngBuf;
		UINT32 freeEgrBuf;

		UINT16 numLane;

		PcieEndPoint();
		~PcieEndPoint();

		void initEp(UINT16 nPort, UINT32 sBuf, UINT16 nLane);
		
		bool isFreeIngBuf(PciePacket * pkt);
		void bufIng(PciePacket * pkt);
		void resvIngPortRsc(PciePacket * pkt);

		bool isFreeEgrBuf(PciePacket * pkt);
		void bufEgr(PciePacket * pkt);
		void resvEgrPortRsc(PciePacket * pkt);
		void relEgrPortBuf(PciePacket * pkt);


		void popFrontIo(PKT_TYPE type, UINT8 parLvl);
		PciePacket * genRpdPacket(UINT32 id, FLASH_REQ_TYPE type, UINT32 io, UINT32 flash);
};



#endif
