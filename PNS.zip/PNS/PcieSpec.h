
#ifndef _PcieSpec_h__
#define _PcieSpec_h__

#define SIZE_PACKET_HEADER 12
#define SIZE_PAYLOAD_MAX 4096

#define TRANSFER_RATE_GB 1

#define TRANSFER_RATE_V1 268435456	// (B/s) - 2Gb/s
#define TRANSFER_RATE_V2 536870912	// (B/s) - 4Gb/s
#define TRANSFER_RATE_V3 1057635696	// (B/s) - 7.88Gb/s
#define TRANSFER_RATE_V4 2113929216	// (B/s) - 15.75Gb/s

#endif
