
#ifndef _TypeSystem_h__
#define _TypeSystem_h__


typedef unsigned char           UINT8;
typedef unsigned short          UINT16;
typedef unsigned int            UINT32;
typedef unsigned long long int  UINT64;



#endif
