
#ifndef _FlashDev_h__
#define _FlashDev_h__

#include "TypeSystem.h"

#define RD_LAT 50000
#define WR_LAT 650000
#define TXR_LAT 25
#define PAGE_SIZE 4096

typedef enum {
	FLASH_REQ_TYPE_R,
	FLASH_REQ_TYPE_W,
} FLASH_REQ_TYPE;


class FlashDev {

	public:
		bool running;	
		UINT64 runTime;
		UINT64 relTime;
		
		FLASH_REQ_TYPE reqType;
		
		UINT32 ioId;
		UINT8 parLvl;
	
		FlashDev();
		~FlashDev();

		UINT64 reqRun(FLASH_REQ_TYPE type, UINT32 io, UINT8 parallel, UINT64 curTime);
		UINT64 cplRun();
		
		bool isRun();
		UINT64 getRelTime();
		FLASH_REQ_TYPE getIoType();
		UINT32 getIoId();
		UINT8 getParLvl();
};


#endif

