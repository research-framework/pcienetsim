
#ifndef _PcieSwitch_h__
#define _PcieSwitch_h__


#include <vector>
#include <queue>
#include "TypeSystem.h"
#include "PciePacket.h"

#define LIMIT_SW_PORT 1024


class PcieSwitch {

	public:
		int swId;			//identifier within a layer
		UINT16 numSubDev;		//# of devices under this sw

		UINT16 numPort;
		UINT32 sizeBuf;
		UINT16 numLane;

		std::vector< std::queue<PciePacket *> *> SwitchPortIngQ;
		UINT32 freeIngBuf[LIMIT_SW_PORT];
		bool busyPortIng[LIMIT_SW_PORT];	
		UINT64 portRelTime[LIMIT_SW_PORT];

		std::vector< std::queue<PciePacket *> *> SwitchPortEgrQ[LIMIT_SW_PORT];
		UINT32 freeEgrBuf[LIMIT_SW_PORT];
		UINT32 freeUpEgrBuf[LIMIT_SW_PORT];

		UINT16 curUpArb;	

		PcieSwitch(int id, UINT16 dev);
		~PcieSwitch();

		void initSw(UINT16 nPort, UINT32 sBuf, UINT16 nLane);
		int detEgrPort(bool lastLay, PciePacket * pkt);

		bool isFreeIngBuf(UINT16 nPort, PciePacket * pkt);
		void bufIngPort(UINT16 nPort, PciePacket * pkt);
		void resvIngPortRsc(UINT16 nPort, PciePacket * pkt);

		bool isFreeEgrBuf(UINT16 srcPort, UINT16 dstPort, PciePacket * pkt);		
		void bufEgrPort(UINT16 src, UINT16 dst, PciePacket * pkt);	
		void resvEgrPortRsc(UINT16 srcPort, UINT16 dstPort, PciePacket * pkt);
		void relEgrPortBuf(UINT16 srcPort, UINT16 dstPort, PciePacket * pkt);
	
		void startSwitching(UINT16 nPort);
		void endSwitching(UINT16 nPort);
		bool statSwitching(UINT16 nPort);
	
		void setPortRelTime(UINT16 nPort, UINT64 nTime);
		UINT64 getPortRelTime(UINT16 nPort);
	
		UINT16 arbitRR();
};


#endif

