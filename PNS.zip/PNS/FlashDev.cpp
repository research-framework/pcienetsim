
#include "FlashDev.h"


using namespace std;


FlashDev::FlashDev()
{
	//cout << "flash device created" << endl;
	this->running = false;
}



FlashDev::~FlashDev()
{
	//cout << "flash destructed"" << endl;
}



UINT64 FlashDev::reqRun(FLASH_REQ_TYPE type, UINT32 io, UINT8 parallel, UINT64 curTime)
{
	this->running = true;
	this->reqType = type;	
	this->ioId = io;
	this->parLvl = parallel;

	UINT64 moveTime = TXR_LAT * PAGE_SIZE * parLvl;

	if(type == FLASH_REQ_TYPE_R)
	{
		this->relTime = curTime + RD_LAT + moveTime;
		this->runTime = RD_LAT + moveTime;
	}
	else if(type == FLASH_REQ_TYPE_W)
	{
		this->relTime = curTime + WR_LAT + moveTime;
		this->runTime = WR_LAT + moveTime;
	}

	return this->runTime;
}



UINT64 FlashDev::getRelTime()
{
	return this->relTime;
}



UINT64 FlashDev::cplRun()
{
	this->running = false;

	return (UINT64)((this->parLvl) * PAGE_SIZE);
}



bool FlashDev::isRun()
{
	return this->running;
}



FLASH_REQ_TYPE FlashDev::getIoType()
{
	return this->reqType;
}
                


UINT32 FlashDev::getIoId()
{	
	return this->ioId;
}


UINT8 FlashDev::getParLvl()
{
	return this->parLvl;
}

