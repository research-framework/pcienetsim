
#ifndef _ParamMgr_h__
#define _ParamMgr_h__

#include "TypeSystem.h"
#include "SysConfig.h"


//#define FILENAME "abc"

typedef enum {
	PARAM_TYPE_SYS,
	PARAM_TYPE_RC,
	PARAM_TYPE_SW,
	PARAM_TYPE_EP,
	PARAM_TYPE_LINK,
	PARAM_TYPE_NONE,
} PARAM_TYPE;


class ParamMgr {

	public:
		
		ParamMgr();
		~ParamMgr();

		void mapValue();
		void mapSysValue(char * item, int value);
		void mapRcValue(char * item, int value);
		void mapSwValue(char * item, int layer, int value);	
		void mapEpValue(char * item, int value);
		void mapLinkValue(char * item, int layer, int value);
	};


#endif

