
#ifndef _PcieLink_h__
#define _PcieLink_h__


#include "TypeSystem.h"
#include "PcieSpec.h"
#include "PciePacket.h"



enum LINK_DIR {
	LINK_DIR_UP,
	LINK_DIR_DOWN
};


class PcieLink {

	public:
		int linkId;
		UINT16 numLane;
		UINT64 dataRate;	

		bool upInUse;
		UINT64 upRelTime;
		PciePacket * upLink;
	
		bool downInUse;
		UINT64 downRelTime;
		PciePacket * downLink;

		PcieLink();
		~PcieLink();
		void initLink(UINT16 nVer, UINT16 nLane);
		
		void getUpLink(PciePacket * pkt);
		PciePacket* relUpLink();
		bool isUpInUse();
		UINT64 setUpRelTime(UINT64 gTime, UINT16 sizePkt);
		UINT64 getUpRelTime();

		void getDownLink(PciePacket * pkt);
		PciePacket* relDownLink();
		bool isDownInUse();
		UINT64 setDownRelTime(UINT64 gTime, UINT16 sizePkt);
		UINT64 getDownRelTime();

};


#endif

