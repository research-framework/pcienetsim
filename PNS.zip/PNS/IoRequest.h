
#ifndef _IoRequest_h__
#define _IoRequest_h__

#include "TypeSystem.h"
#include "PciePacket.h"

#define INTER_PAR_LEV 1024


using namespace std;



typedef enum {
        REQ_TYPE_R,
        REQ_TYPE_W
} REQ_TYPE;



class IoRequest {
	
	public:
	
		UINT32 reqId;

		REQ_TYPE reqType;	
		UINT64 reqAddr;
		UINT16 reqSize;

		UINT16 numTarDev;
		vector<UINT64> lbn[INTER_PAR_LEV];
		
		vector<PciePacket *> reqPktList;			
		vector<PciePacket *> rpdPktList;
		UINT16 numWaitRpdPkt;
	
		IoRequest()
		{
			numTarDev = 0;
			numWaitRpdPkt = 0;
		}	

};


#endif
