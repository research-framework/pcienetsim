
#ifndef _SysConfig_h__
#define _SysConfig_h__

#include "TypeSystem.h"


typedef struct {
        UINT8 numSwLayer;
        UINT16 sizePg;
        UINT16 numDev;
        UINT8 numPar;
        UINT8 numDigDev;
        UINT8 numDigPar;

	UINT16 sizeCmdQ;
} SysConfig;


typedef struct {
        UINT16 numPort;
        UINT16 numLane; 
} RcConfig;


typedef struct {
        UINT16 numSwitch;
        UINT16 numPort;
        UINT16 numLane;
        UINT32 sizePortBuf;
	UINT16 latSw;
} SwConfig;


typedef struct {
        UINT16 numEndpoint;
        UINT16 numPort;
        UINT16 numLane;
        UINT32 sizePortBuf;

} EpConfig;


typedef struct {
	UINT16 numVer;
	UINT16 numLink;
	UINT16 numLane;
	
} LinkConfig;


#endif

