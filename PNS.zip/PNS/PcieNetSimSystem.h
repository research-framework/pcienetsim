
#ifndef _PcieNetSimSystem_h__
#define _PcieNetSimSystem_h__

#include <vector>
#include <fstream>
#include "IoRequest.h"
#include "PciePacket.h"
#include "PcieRootComplex.h"
#include "PcieSwitch.h"
#include "PcieEndPoint.h"
#include "PcieLink.h"
#include "FlashDev.h"


#define LIMIT_SW_LAY 10
#define LIMIT_DEV_NUM 8192
#define LIMIT_RC_NUM 4

#define BRKDOWN_FILE_NAME "output-breakdown"
#define STAT_FILE_NAME "output-system"


typedef struct {
        FILE * inIoTrace;
	FILE * inConfig;
        FILE * outIoBrkdwn;
        FILE * outSysStat;
	FILE * outEPB;
} FilePointers;


using namespace std;

class PcieNetSimSystem {

	public:
		FILE * brkOut;		
		FILE * statOut;		
		
		bool moreCmd;
		vector<IoRequest *> reqList;
		int freeCmdQEnt;

		UINT32 numReq;
		UINT32 numPkt;
		UINT32 cplReq;
	
		UINT64 gTime;
		UINT64 advTime;

		PcieRootComplex * Rc;
		vector<PcieSwitch *> SwTree[LIMIT_SW_LAY];
		vector<PcieEndPoint *>  Ep;	
		vector<PcieLink *> Link[LIMIT_SW_LAY];
		vector<FlashDev *> Flash;
	
		
		PcieNetSimSystem();
		~PcieNetSimSystem();

		void setSysConfig();
		bool buildSystem();

		bool addIoRequest(char reqType, UINT64 reqAdrr, UINT16 reqSize);
		bool modIoRequest(UINT32 reqId);
		bool cplIoRequest(IoRequest * io, PciePacket * pkt);
		bool divIoRequest(IoRequest * io);	
		
		PciePacket * genPackets(UINT32 reqId, REQ_TYPE op, UINT16 dev, UINT32 par);	
		UINT16 calDstDev(UINT64 lbn);


		UINT64 getGblTime();
		void setAdvTime(UINT64 adv);
		void advClock();
		
		//void simulateSys(char * ioTraceName);
		void simulateSys();

		void getIoRequest(FILE * ioReq);
		void updateSys();
		void updateRc();
		void updateSwTree();
		void updateEp();
		void updateLink();
	
		void updatePktTime(PciePacket * pkt);		
		void setupPktTime(PciePacket * pkt, UINT64 flashLat);
	
		void addPktIo(PciePacket * pkt);
		void cplPktIo(PciePacket * pkt);

		UINT64 statLinkTime[LIMIT_SW_LAY][LIMIT_DEV_NUM];
		void statPrint(UINT64 runTime);

		UINT64 proData[LIMIT_RC_NUM];
		UINT64 conData[LIMIT_RC_NUM];
		UINT64 movData[LIMIT_RC_NUM][LIMIT_RC_NUM];

		UINT64 totalData;
		UINT64 flashTime[LIMIT_DEV_NUM];
		UINT64 moveWrite;
};


#endif

