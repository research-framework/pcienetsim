
#include <queue>
#include <iostream>
#include "SysConfig.h"
#include "PcieRootComplex.h"

using namespace std;

extern SysConfig SysConf;
extern RcConfig RcConf;



PcieRootComplex::PcieRootComplex() 
{	
	//std::cout << "rc contructor" << std::endl;
}



PcieRootComplex::~PcieRootComplex()
{
	//std::cout << "rc desctructor" << std::endl;
}



void PcieRootComplex::initRc(UINT16 nPort, UINT16 nLane)
{
	this->numPort = nPort;
	this->numLane = nLane;	

	//create egress port buffers
	for(int i=0; i<this->numPort; i++)
	{
		queue<PciePacket *> * rcq = new queue<PciePacket *>();
		(this->RootPortQ).push_back(rcq);
	}
}



int PcieRootComplex::detEgrPort(PciePacket * pkt)
{
	int rp = (pkt->dstDev) / (SysConf.numDev / RcConf.numPort);
	return rp;
}



