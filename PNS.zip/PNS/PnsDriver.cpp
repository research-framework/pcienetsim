
#include <iostream>
#include <fstream>
#include <string.h>
#include <vector>

#include "TypeSystem.h"
#include "ParamMgr.h"
#include "PcieNetSimSystem.h"


using namespace std;

extern FilePointers fps;

int main(int argc, char* argv[])
{

	//check execution command line
	if(argc == 5)
	{
		if(strcmp(argv[1], "--conf") ||  strcmp(argv[3], "--trace"))
		{
			cout << "run param error" << endl;
			return -1;
		}		
	}	
	else
	{
		cout << "run param error" << endl;
		return -1;
	}


	//open in/out files
	fps.inIoTrace = fopen(argv[4], "rt");
	if(!fps.inIoTrace)
	{
		cout << "invalid trace file" << endl;
		return -1;
	}

	fps.inConfig = fopen(argv[2], "rt");
	if(!fps.inConfig)
	{
		cout << "invalid config file" << endl;
		return -1;
	}

        //this->brkOut = fopen(BRKDOWN_FILE_NAME, "wt");
        //this->statOut = fopen(STAT_FILE_NAME, "wt");
	

	//read config file	
	ParamMgr config;
	config.mapValue();

	
	//build PNS system	
	PcieNetSimSystem PnsSystem;
	//PnsSystem.setSysConfig();
	if(!PnsSystem.buildSystem())
	{
		std::cout << "building system failed" << std::endl;
		return -1;
	}


	//run PNS system
	PnsSystem.simulateSys();

	

	//PnsSystem.modIoRequest(4);
	

	return 0;

}
